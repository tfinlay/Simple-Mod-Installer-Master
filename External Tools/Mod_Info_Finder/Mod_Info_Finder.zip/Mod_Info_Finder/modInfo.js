function load() {
    var xhttp = new ActiveXObject("MSXML2.XMLHTTP.6.0");
    
    xhttp.open("GET", "file:///C:/Tfff1/Simple_MC/Mod_Info_Finder/Mod_Data/mcmod.info", false);
    xhttp.send("");
    
    var responseFixed = '{"modList": ' + xhttp.responseText + "}";
    
    var jsonResponse = JSON.parse(responseFixed);
    
    var xhttp2 = new ActiveXObject("MSXML2.XMLHTTP.6.0");
    
    xhttp2.open("GET", "file:///C:/Tfff1/Simple_MC/Mod_Info_Finder/Mod_Data/installerInfo.json", false);
    xhttp2.send("");
    
    var mcVersion = JSON.parse(xhttp2.responseText).collectionMCVersion;
    
    //Shorthand for jsonResponse.modList[0]
    var modlist = jsonResponse.modList[0];
    document.getElementById("left").innerHTML = '<h1>' + modlist.name + '</h1><img width="100%" height="70px" src="file:///C:/Tfff1/Simple_MC/Mod_Info_Finder/Mod_Data/' + modlist.logoFile.replace(/\\/g, "/") + '">';
    document.getElementById("modid").innerHTML = document.getElementById("modid").innerHTML + " " + modlist.modid;
    document.getElementById("description").innerHTML = modlist.description;
    document.getElementById("version").innerHTML = document.getElementById("version").innerHTML + " " + modlist.version;
    document.getElementById("mcversion").innerHTML = document.getElementById("mcversion").innerHTML + " " + modlist.mcversion;
    
    if (modlist.mcversion != mcVersion) {
        document.getElementById("mcversion").setAttribute("style", "color:red;");
        document.getElementById("mcversion").setAttribute("title", "WARNING: This mod's Minecraft Version is not the same version that your Collection uses!\n\nLook for a version of this mod for Minecraft " + mcVersion.toString());
    }
    
    document.getElementById("URL").innerHTML = modlist.url;
    document.getElementById("URL").setAttribute("href", modlist.url);
    
    document.getElementById("credits").innerHTML = document.getElementById("credits").innerHTML + " " + modlist.credits;
    if (modlist.authorList == undefined) {
        document.getElementById("authors").innerHTML = document.getElementById("authors").innerHTML + " " + modlist.authors;
    }
    else {
        document.getElementById("authors").innerHTML = document.getElementById("authors").innerHTML + " " + modlist.authorList;
    }
    
}